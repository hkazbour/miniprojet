# PC Setup Requirements
* Windows 10
* Python 2.7
    * pip install selenium
* [Windows Performance Toolkit](https://msdn.microsoft.com/en-us/windows/hardware/commercialize/test/wpt/index)
    * With xperf added to the system path