#!/bin/bash
while true
do
	php status.php
#	php validate.php
	php submit.php
	sleep 30
done
